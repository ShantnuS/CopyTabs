# CopyTabs

Browser extension that copies open tabs into clipboard

## Contributing

PRs accepted.

## Credits

<div>Icons made by <a href="https://www.flaticon.com/authors/google" title="Google">Google</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a>.</div>
